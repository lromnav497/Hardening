# Proyecto 1.2 – Bastionado del Arranque en Debian

---

**Guía en GitHub Pages:**
[https://lromnav497.github.io/Hardening/Proyecto-1-Bastionado-del-arranque-del-sistema/DEBIAN/Guia-DEBIAN](https://lromnav497.github.io/Hardening/Proyecto-1-Bastionado-del-arranque-del-sistema/DEBIAN/Guia-DEBIAN)

---
