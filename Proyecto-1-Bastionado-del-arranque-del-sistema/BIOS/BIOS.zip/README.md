# Proyecto 1.1 – Bastionado de BIOS/UEFI

---

**Guía en GitHub Pages:**
[https://lromnav497.github.io/Hardening/Proyecto-1-Bastionado-del-arranque-del-sistema/BIOS/Guia-BIOS](https://lromnav497.github.io/Hardening/Proyecto-1-Bastionado-del-arranque-del-sistema/BIOS/Guia-BIOS)

---
